<?php
echo "<p>Copyright &copy; 2019-" . date("Y") . "fashion.in</p>";
?>

<!-- begin footer -->
<p>Web Site last changed on 14/3/2019.</p>
</body>
</html>
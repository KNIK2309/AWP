
  /*alert("Welcome");*/ 
    var count; 
     count=45; 
      count++; 
      
      console.log (" Count ="+ count); 

   var sayHi=function()
   {  
        console.log( "button is clicked !"); 
      }